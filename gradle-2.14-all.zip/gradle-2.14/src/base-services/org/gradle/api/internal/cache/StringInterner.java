/*
 * Copyright 2016 the original author or authors.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package org.gradle.api.internal.cache;

import com.google.common.collect.Interner;
import com.google.common.collect.Interners;

public class StringInterner implements Interner<String> {
    private final Interner<String> interner;

    public StringInterner() {
        this.interner = Interners.newWeakInterner();
    }

    @Override
    public String intern(String sample) {
        if (sample == null) {
            return null;
        }
        return interner.intern(sample);
    }
}
